import numpy as np
import pickle

class RunningMeanStd(object):
    # https://en.wikipedia.org/wiki/Algorithms_for_calculating_variance#Parallel_algorithm
    # mean-std is not always the 2d text!
    def __init__(self, epsilon=1e-4, shape=()):
        self.mean = np.zeros(shape, 'float64')
        self.var = np.ones(shape, 'float64')        
        self.count = epsilon
        self.std = np.sqrt(self.var)

    def update(self, x):
        batch_mean = np.mean(x, axis=0)
        batch_var = np.var(x, axis=0)
        batch_count = x.shape[0]

        delta = batch_mean - self.mean
        tot_count = self.count + batch_count

        new_mean = self.mean + delta * batch_count / tot_count        
        m_a = self.var * (self.count)
        m_b = batch_var * (batch_count)
        M2 = m_a + m_b + np.square(delta) * self.count * batch_count / (self.count + batch_count)
        new_var = M2 / (self.count + batch_count)

        new_count = batch_count + self.count

        self.mean = new_mean
        self.var = new_var
        self.std = np.sqrt(self.var)
        self.count = new_count

    def save_mean_std(self, path):
        _path = path
        mean_std_arr = np.array([self.mean, self.std]) # shape (2,), indexing by [0] and [1]

        with open ( _path, 'wb') as f:             
            pickle.dump(mean_std_arr, f)

    def load_mean_std(self, path):
        # loads mean and stddev derived in training session
        # only used for test session
        _path = path
        with open(_path, 'rb') as f:
            _mean_std_arr = pickle.load(f)
        self.mean = _mean_std_arr[0] 
        self.std = _mean_std_arr[1] 