# ddpg-ros-keras
An implementation of the Deep Deterministic Policy Gradient (DDPG) algorithm using Keras/Tensorflow with the robot simulated using ROS/Gazebo/MoveIt!

https://robosamir.github.io/DDPG-on-a-Real-Robot/
