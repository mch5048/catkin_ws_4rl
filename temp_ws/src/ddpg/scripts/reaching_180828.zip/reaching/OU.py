
import random
import numpy as np 

class OU(object):
    def function(self, x_prev, mu, theta, sigma):

    	dt = 0.07   
        x = x_prev + theta * (mu - x_prev) * dt + sigma * np.sqrt(dt) * np.random.randn(1)
        return x
