#!/usr/bin/env python
import numpy as np
import random
from keras.models import model_from_json, Model
from keras.models import Sequential
from keras.layers.core import Dense, Dropout, Activation, Flatten
from keras.optimizers import Adam
from keras import losses
import tensorflow as tf
from keras.engine.training import *
import json
import os
from PriorReplayBuffer import ReplayBuffer
from ActorNetwork import ActorNetwork
from CriticNetwork import CriticNetwork
from new_robotGame import robotGame
import time
from tempfile import TemporaryFile
from OU import OU
from collections import deque
import rospy
import time
import pickle

OU = OU()


path="/home/irobot/catkin_ws/src/ddpg/scripts/"

#path ="/media/dalinel/Maxtor/ddpg/"
def playGame(train_indicator=0):    #1 means Train, 0 means simply Run
    BUFFER_SIZE = 15000
    BATCH_SIZE = 32
    GAMMA = 0.99
    TAU = 0.001     #Target Network HyperParameters
    LRA = 0.0001    #Learning rate for Actor
    LRC = 0.001     #Lerning rate for Critic
    N_STEP_RETURN = 5

    action_dim = 7  #num of joints being controlled
    state_dim_rgb = [100,100,3]  #num of features in state refer to 'new_robotGame/reset'
    pos_dim_robot = 7  # 7 joint positions + gripper pos (last)
    full_dim_robot = 14  # 7 joint pos + 7 joint vels + gripper pos (last)
    state_dim_object = 3  #num of features in state refer to 'new_robotGame/eset'
    episode_count = 4000 if (train_indicator) else 10
    resultArray=np.zeros((episode_count,2))
    max_steps = 500
    reward = 0
    done = False
    step = 0
    epsilon = 0.3 if (train_indicator) else 0.0
    indicator = 0
    buffer_added = False
    joint_vel_scale_base = 5.
    joint_vel_scale_shoulder_1 = 5.
    joint_vel_scale_shoulder_2 = .5
    joint_vel_scale_shoulder_3 = 5.
    joint_vel_scale_wrist_1 =1.
    joint_vel_scale_wrist_2 =1.
    joint_vel_scale_wrist_3 =1.
    joint_torque_scale_base = 15.0
    joint_torque_scale_shoulder_1 = 7
    joint_torque_scale_shoulder_2 = 5
    joint_torque_scale_shoulder_3 = 3.0
    joint_torque_scale_wrist_1 =2.0
    joint_torque_scale_wrist_2 =2.0
    joint_torque_scale_wrist_3 =2.0
    memory = deque()
    show_reward = False
    total_time = 0
    dagger_data = 'traj_dagger.bin'

    #Tensorflow GPU optimization
    config = tf.ConfigProto()
    config.gpu_options.allow_growth = True
    sess = tf.Session(config=config)
    from keras import backend as K
    K.set_session(sess)
    # if(train_indicator == 1):
    K.set_learning_phase(1)

    actor = ActorNetwork(sess, state_dim_rgb, pos_dim_robot, action_dim, BATCH_SIZE, TAU, LRA)
    critic = CriticNetwork(sess, full_dim_robot, state_dim_object, action_dim, BATCH_SIZE, TAU, LRC)
    buff = ReplayBuffer(BUFFER_SIZE)    #Create replay buffer

    # Generate a Torcs environment
    env = robotGame()

    os.chdir('/home/irobot/catkin_ws/src/ddpg/scripts/reaching')
    if os.path.exists(dagger_data) and train_indicator:
        print 'initialize the replay buffer with demo data'
        with open(dagger_data, 'rb') as f:
            dagger = pickle.load(f)
            for idx, item in enumerate(dagger):

                if idx == 10:
                    print item
                buff.add(item[0],item[1],item[2],item[3],item[4])
            print (idx, 'data has retrieved')

    #Now load the weight
    print("Now we load the weight")
    try:
        actor.model.load_weights(path+"weights/actormodel_.h5")
        critic.model.load_weights(path+"weights/criticmodel_.h5")
        actor.target_model.load_weights(path+"weights/actormodel_.h5")
        critic.target_model.load_weights(path+"weights/criticmodel_.h5")
        print("Weight load successfully")
    except:
        print("Cannot find the weight")


    for i in range(episode_count): # pseudo: for each episode

        rospy.loginfo("Now It's EPISODE{0}".format(i))
        color_obs_t, joint_pos_t, joint_vels_t = env.reset() #(self.color_obs, self.joint_values)
        # color_obs_t = np.expand_dims(color_obs_t, axis=0)
        obj_state_t = env.getObjPose()

        s_t = [np.array(color_obs_t), np.array(joint_pos_t), np.array(joint_vels_t),  np.array(obj_state_t)]

        # print s_t[0]
        # normalized obs
        s_t[1] = (s_t[1] - s_t[1].mean())/s_t[1].std()
        s_t[1] = s_t[1].reshape(1,s_t[1].shape[0])
        s_t[2] = (s_t[2] - s_t[2].mean())/s_t[2].std()
        s_t[2] = s_t[2].reshape(1,s_t[2].shape[0])
        s_t[3] = (s_t[3] - s_t[3].mean())/s_t[3].std()
        s_t[3] = s_t[3].reshape(1,s_t[3].shape[0])


        total_reward = 0.
        step = 0
        # is this part necessary????
        for j in range(max_steps): # pseudo: for each timestep
            start_time = time.time()
            # initialize variables  

            mse_loss = 0
            a_t = np.zeros([1,action_dim])
            noise_t = np.zeros([1,action_dim])


            # Assymetric network, actor requires RGB observation + 
            # 1D array input should be re-shaped
            # s_t.reshape(1, s_t.shape[0])
            s_t[0] = np.reshape(s_t[0],(-1,100,100,3))

            '''
            default_joint_tolerance = 0.05  # rad
            default_max_linear_speed = 0.6  # m/s
            default_max_linear_accel = 0.6  # m/s/s
            default_max_rot_speed = 1.57  # rad/s
            default_max_rot_accel = 1.57  # rad/s/s
            '''

            a_t_original = actor.model.predict([s_t[0], s_t[1]]) #r prediction (action) from CNN

            if  np.mod(i, 10) == 0:
                print ('action @ timestep %d' %i)
                print a_t_original
            # noise_t[0][0] = train_indicator * max(epsilon, 0) * OU.function(a_t_original[0][0],  0.0 , 1.00, 0.05) # mu, theta, sigma
            # noise_t[0][1] = train_indicator * max(epsilon, 0) * OU.function(a_t_original[0][1],  0.0 , 1.00, 0.20)
            # noise_t[0][2] = train_indicator * max(epsilon, 0) * OU.function(a_t_original[0][2],  0.0 , 1.00, 0.20)
            # noise_t[0][3] = train_indicator * max(epsilon, 0) * OU.function(a_t_original[0][3],  0.0 , 1.00, 0.20)
            # noise_t[0][4] = train_indicator * max(epsilon, 0) * OU.function(a_t_original[0][4],  0.1 , 0.6, 0.30)
            # noise_t[0][5] = train_indicator * max(epsilon, 0) * OU.function(a_t_original[0][5],  0.1 , 0.6, 0.30)
            # noise_t[0][6] = train_indicator * max(epsilon, 0) * OU.function(a_t_original[0][6],  0.1 , 0.6, 0.30)
            # noise_t[0][7] = train_indicator * max(epsilon, 0) * OU.function(a_t_original[0][2],  0.0 , 1.00, 0.15) # for gripper

                # a_type = "Explore"
                # a_t = np.random.uniform(-1,1, size=(1,action_dim))




            # a_t[0][0] = joint_vel_scale_base * OU.function(a_t_original[0][0], 0.0 , .15, 0.05) #x_prev,  mu, theta, sigma
            # a_t[0][1] = joint_vel_scale_shoulder_1 * OU.function(a_t_original[0][1], 0.0 , 0.15, 0.10)
            # a_t[0][2] = joint_vel_scale_shoulder_2 * OU.function(a_t_original[0][2], 0.0 , 0.15, 0.20)
            # a_t[0][3] = joint_vel_scale_shoulder_3 * OU.function(a_t_original[0][3], 0.0 , 0.15, 0.10)
            # a_t[0][4] = joint_vel_scale_wrist_1 * OU.function(a_t_original[0][4], 0.0 , .3, 0.30)
            # a_t[0][5] = joint_vel_scale_wrist_2 * OU.function(a_t_original[0][5], 0.0 , .4, 0.50)
            # a_t[0][6] = joint_vel_scale_wrist_3 * OU.function(a_t_original[0][6], 0.0 , .3, 0.30)


            a_t[0][0] = joint_torque_scale_base * OU.function(a_t_original[0][0], 0.0 , 1.00, 0.05) #x_prev,  mu, theta, sigma
            a_t[0][1] = joint_torque_scale_shoulder_1 * OU.function(a_t_original[0][1], 0.0 , 1.00, 0.20)
            a_t[0][2] = joint_torque_scale_shoulder_2 * OU.function(a_t_original[0][2], 0.0 , 1.00, 0.20)
            a_t[0][3] = joint_torque_scale_shoulder_3 * OU.function(a_t_original[0][3], 0.0 , 1.00, 0.20)
            a_t[0][4] = joint_torque_scale_wrist_1 * OU.function(a_t_original[0][4], 0.0 , 0.6, 0.30)
            a_t[0][5] = joint_torque_scale_wrist_2 * OU.function(a_t_original[0][5], 0.0 , 0.6, 0.30)
            a_t[0][6] = joint_torque_scale_wrist_3 * OU.function(a_t_original[0][6], 0.0 , 0.6, 0.30)
            
            
            # a_t[0][7] = a_t_original[0][7] + noise_t[0][7]

            # distance,color_obs, tjv, reward, done
            # pseudo: Execute action a_t and observe reward r_t and observe new state s_t+1


            dist, color_obs_t_1, joint_pos_t_1, joint_vels_t_1, r_t, done = env.step(a_t[0], step)
            obj_state_t_1 = env.getObjPose()
            s_t_1 = [np.array(color_obs_t_1), np.array(joint_pos_t_1), np.array(joint_vels_t_1),  np.array(obj_state_t_1)]

            # normalized obs
            s_t_1[1] = (s_t_1[1] - s_t_1[1].mean())/s_t_1[1].std()
            s_t_1[1] = s_t_1[1].reshape(1,s_t_1[1].shape[0])
            s_t_1[2] = (s_t_1[2] - s_t_1[2].mean())/s_t_1[2].std()
            s_t_1[2] = s_t_1[2].reshape(1,s_t_1[2].shape[0])
            s_t_1[3] = (s_t_1[3] - s_t_1[3].mean())/s_t_1[3].std()
            s_t_1[3] = s_t_1[3].reshape(1,s_t_1[3].shape[0])

            s_t_1[0] = np.reshape(s_t_1[0],(-1,100,100,3))



            # N-step return implementation!!
            # Keep the experience in memory until 'N_STEP_RETURN' steps has
            # passed to get the delayed return r_1 + ... + gamma^n r_n
            # for N-step return
            memory.append((s_t, a_t[0], r_t))

            if len(memory) >= (N_STEP_RETURN-1): # if buffer has more than 4 memories, execute
                s_t, a_t, discount_r = memory.popleft()
                for idx, (si, ai, ri) in enumerate(memory):
                    discount_r += ri * GAMMA ** (idx + 1)

                # self.buffer.add((s_mem, a_mem, discount_r, s_, 1 if not done else 0))
                buff.add(s_t, a_t, discount_r, s_t_1, done)      #A s_t , s_t+N, a_t+N, disc_r
                buffer_added = True

            # print buff.count()
            # pseudo: store transition (s_t, a_t, r_t s_t+1 ) in Replay buffer R

            # pseudo: sample a random minibatch of N trainsitions
            # return samples, indices, np.array(weights, dtype=np.float32) # returns a list()
            if not train_indicator:
                rospy.sleep(0.05)
            if buffer_added and train_indicator:
                batch, indices, weights_array = buff.getBatch(BATCH_SIZE)
                states = ([e[0] for e in batch])
                actions = np.asarray([e[1] for e in batch])
                rewards = np.asarray([e[2] for e in batch])
                n_step_states = ([e[3] for e in batch])
                dones = np.asarray([e[4] for e in batch])
                y_t = np.asarray([e[1][0] for e in batch])



                sampled_img_state_n = np.array([img[0] for img in n_step_states])
                sampled_img_state_n = np.reshape(sampled_img_state_n,(-1,100,100,3))

                # sampled_img_state_n = np.expand_dims(sampled_img_state_n, axis=0)


                sampled_joint_pos_state_n = np.array([pos[1] for pos in n_step_states])
                sampled_joint_vel_state_n = np.array([vel[2] for vel in n_step_states])
                sampled_obj_state_n = np.array([obj[3] for obj in n_step_states])


                sampled_img_state = np.array([img[0] for img in states])



                # sampled_img_state = np.expand_dims(sampled_img_state, axis=0)

                sampled_joint_pos_state = np.array([pos[1] for pos in states])
                sampled_joint_vel_state = np.array([vel[2] for vel in states])
                sampled_obj_state = np.array([obj[3] for obj in states])


                # target Actor requires RGB and robot pos state @ t+N
                # target Critic requires full state @t+N ; full state  = 


                full_state_t = np.concatenate((sampled_joint_pos_state, sampled_joint_vel_state))

                full_state_t_n = np.concatenate((sampled_joint_pos_state_n, sampled_joint_vel_state_n))


                # squeeze the dimension


                reduced_full_state_t_n = np.reshape(full_state_t_n,(-1,14))
                reduced_full_state_t = np.reshape(full_state_t,(-1,14))



                reduced_sampled_obj_state_n = np.reshape(sampled_obj_state_n,(-1,3))
                reduced_sampled_obj_state = np.reshape(sampled_obj_state,(-1,3))

                sampled_joint_pos_state_n = np.reshape(sampled_joint_pos_state_n,(-1,7))
                sampled_joint_pos_state = np.reshape(sampled_joint_pos_state,(-1,7))

                '''
                Arguments

                x: The input data, as a Numpy array (or list of Numpy arrays if the model has multiple inputs).
                batch_size: Integer. If unspecified, it will default to 32.
                verbose: Verbosity mode, 0 or 1.
                steps: Total number of steps (batches of samples) before declaring the prediction round finished. Ignored with the default value of None.
                Returns

                Numpy array(s) of prediction
                '''
                # It should be batch prediction

                # print 'Checking for the batch size'
                # print reduced_full_state_t_n.shape
                # print sampled_img_state
                # print sampled_img_state_n.shape
                # print sampled_joint_pos_state_n.shape
                # print '--------------------------------------'

                target_q_values = critic.target_model.predict([reduced_full_state_t_n, reduced_sampled_obj_state_n, actor.target_model.predict([sampled_img_state_n, sampled_joint_pos_state_n])])
                # target_q_values = critic.target_model.predict([sampled_img_state_n, sampled_joint_pos_state_n, actor.target_model.predict([full_state_t_n, sampled_obj_state_n])])

                # predict value for calculatign loss 
                q_values = critic.model.predict([reduced_full_state_t_n, reduced_sampled_obj_state_n, actions])
                # Numpy array type

                for k in range(len(batch)):
                    if dones[k]:
                        y_t[k] = rewards[k] # if terminal state exists
                    else:
                        y_t[k] = rewards[k] + (GAMMA**N_STEP_RETURN)*target_q_values[k] ## target function update
                        y_t[k] = rewards[k] + (GAMMA**N_STEP_RETURN)*target_q_values[k] ## target function update

                mean_reward = rewards.mean()
                show_reward = True

                if (train_indicator): #training mode
                    # loss += critic.model.train_on_batch([sampled_img_state_n, sampled_joint_pos_state_n, actions], y_t) #Minibatch loss -> MSE, and current estimation is made

                    # batch, indices, weights_array
                    weights_array = weights_array.reshape((32,1))


                    y_t = y_t.reshape((32,1))



                    loss_array = weights_array * (y_t - q_values) ** 2 + 1e-6*np.ones((BATCH_SIZE,1))

                  
                    # update priority weight vector!!
                    buff.update_priorities(indices, loss_array)

                    # MSE loss
                    mse_loss += critic.model.train_on_batch([reduced_full_state_t, reduced_sampled_obj_state, actions], y_t) #Minibatch loss -> MSE, and current estimation is made
                    # Shouldn't it be scalar loss?
                    # from states, and acitons ( sampled batch states and actions)
                    # Keras, Sequential, train_on_batch(self, x, y, sample_weight=None, class_weight=None)

                    sampled_img_state = np.reshape(sampled_img_state,(-1,100,100,3))
                    a_for_grad = actor.model.predict([sampled_img_state, sampled_joint_pos_state])   # action gradient
                    
                    # print a_for_grad
                    # print '!!!!!!'

                    c_states = np.hstack((reduced_full_state_t, reduced_sampled_obj_state))
                    # full, aux, a_grad
                    grads = critic.gradients(reduced_full_state_t, reduced_sampled_obj_state, a_for_grad) # action is not sampled from mini_batch, q_value gradpeint
                    # a_states = [sampled_img_state, sampled_joint_pos_state]
                    actor.train(sampled_img_state, sampled_joint_pos_state, grads)
                    actor.target_train()
                    critic.target_train()
            elapsed_time = time.time() - start_time
            total_time +=elapsed_time

                # buffer_added = False


            if show_reward:
                total_reward += mean_reward
            s_t = s_t_1

            if np.mod(j, 10) == 0:
                print("Episode", i, "Step", step, "Action", a_t, "Total_reward", total_reward, "Loss", mse_loss, "10step-Time", total_time)
                total_time = 0
            step += 1


            if env.checkForTermination():
                print ('==================================================================================')
                print ('Terminates Episode %d due to boundary condition' %i)
                print ('==================================================================================')
                break
            if env.checkForSuccess():
                print ('==================================================================================')
                print ('Terminates Episode %d due to Success' %i)
                print ('==================================================================================')
                break
            if done:
                break

        # buffer_added = False

        if np.mod(i, 25) == 0:
            if (train_indicator):
                print("Now we save model")
                actor.model.save_weights(path+"weights/actormodel_"+str(i)+".h5", overwrite=True)
                critic.model.save_weights(path+"weights/criticmodel_"+str(i)+".h5", overwrite=True)

        print("TOTAL REWARD @ " + str(i) +"-th Episode  : Reward " + str(total_reward))
        print("Total Step: " + str(step))
        print("")
        if (train_indicator):
            resultArray[i][0]=total_reward
            resultArray[i][1]=dist
            np.savetxt(path+'results.txt', resultArray)
            np.save(path+'results.npy', resultArray)
            actor.model.save_weights(path+"weights/actormodel_"+".h5", overwrite=True)
            critic.model.save_weights(path+"weights/criticmodel_"+".h5", overwrite=True)
       

    env.done()
    print("Finish.")

    def _get_transition(self, idx):
        transition = [None] * (self.history + self.n)
        transition[self.history - 1] = self.transitions.get(idx)
        for t in range(self.history - 2, -1, -1):  # e.g. 2 1 0
          if transition[t + 1].timestep == 0:
            transition[t] = blank_trans  # If future frame has timestep 0
          else:
            transition[t] = self.transitions.get(idx - self.history + 1 + t)
        for t in range(self.history, self.history + self.n):  # e.g. 4 5 6
          if transition[t - 1].nonterminal:
            transition[t] = self.transitions.get(idx - self.history + 1 + t)
          else:
            transition[t] = blank_trans  # If prev (next) frame is terminal
        return transition




    # def discount_correct_rewards(r, gamma=GAMMA):
    #   """ take 1D float array of rewards and compute discounted reward """
    #   discounted_r = np.zeros_like(r)
    #   running_add = 0
    #   for t in reversed(range(0, r.size)):
    #     #if r[t] != 0: running_add = 0 # reset the sum, since this was a game boundary (pong specific!)
    #     running_add = running_add * gamma + r[t]
    #     discounted_r[t] = running_add

    #   discounted_r -= discounted_r.mean()
    #   discounted_r /- discounted_r.std()
    #   return discounted_r


if __name__ == "__main__":
    playGame(1)